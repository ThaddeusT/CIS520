#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

void syscall_init (void);

/* My Implementation */
int sys_exit (int status);
/* == My Implementation */

#endif /* userprog/syscall.h */
